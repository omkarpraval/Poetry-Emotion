
import nltk
import os
import glob
import pickle
import re
from os.path import basename
from collections import Counter
from nltk.tokenize import RegexpTokenizer, word_tokenize
from nltk import pos_tag
from nltk.corpus import wordnet as wordn

_needed = [
    "punkt",
    "punkt_tab",
    "averaged_perceptron_tagger",
    "averaged_perceptron_tagger_eng",
    "wordnet",
    "omw-1.4"
]

for _res in _needed:
    try:
        if _res in ("punkt", "punkt_tab"):
            nltk.data.find(f"tokenizers/{_res}")
        elif _res in ("averaged_perceptron_tagger", "averaged_perceptron_tagger_eng"):
            nltk.data.find(f"taggers/{_res}")
        else:
            nltk.data.find(f"corpora/{_res}")
    except LookupError:
        nltk.download(_res, quiet=True)

emotion_of_poems = ['love', 'joy', 'peace', 'sad', 'fear', 'hate']

negation = {
    "aren't": "are not",
    "can't": "cannot",
    "couldn't": "could not",
    "didn't": "did not",
    "doesn't": "does not",
    "don't": "do not",
    "hasn't": "has not",
    "haven't": "have not",
    "hadn't": "had not",
    "isn't": "is not",
    "mightn't": "might not",
    "mustn't": "must not",
    "needn't": "need not",
    "shouldn't": "should not",
    "wasn't": "was not",
    "weren't": "were not",
    "won't": "will not",
    "wouldn't": "would not",
}


def determine_tense_input(sentence):
    """Return a dict with counts of 'future','present','past' tags found in POS tags."""
    text = word_tokenize(sentence)
    tagged = pos_tag(text)
    tense = {}
    tense["future"] = len([word for word in tagged if word[1] == "MD"])
    tense["present"] = len([word for word in tagged if word[1] in ("VBP", "VBZ", "VBG")])
    tense["past"] = len([word for word in tagged if word[1] in ("VBD", "VBN")])
    return tense

def search(token):
    path = "keywordsfile/*.txt"
    files = glob.glob(path)
    tag_list_name = []
    token_found = False
    for file_name in files:
        try:
            with open(file_name, 'r', encoding='utf-8') as f:
                # collect unique words from file
                words = set(w.strip() for line in f for w in line.split() if w.strip())
        except FileNotFoundError:
            continue
        for eachemotion in words:
            if eachemotion == token:
                file1 = basename(file_name)
                file2 = os.path.splitext(file1)[0]
                tag_list_name.append(file2)
                token_found = True
    return tag_list_name, token_found

def insert(token, tag):
    """Append token to the tag file under keywordsfile if that tag exists in emotion_of_poems."""
    if tag in emotion_of_poems:
        path = f"keywordsfile/{tag}.txt"
        try:
            with open(path, 'a', encoding='utf-8') as file:
                file.write("\n" + token)
        except FileNotFoundError:
            # if file missing, create it
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w', encoding='utf-8') as file:
                file.write(token)

def _load_stopwords():
    path = 'requiredfiles/stopword.txt'
    try:
        with open(path, 'r', encoding='utf-8') as f:
            sw = [x.strip().lower() for x in f.readlines() if x.strip()]
            return set(sw)
    except FileNotFoundError:
        # fallback to NLTK stopwords if available
        try:
            from nltk.corpus import stopwords as sw
            return set(w.lower() for w in sw.words('english'))
        except Exception:
            return set()

def _is_file_input(file_input):
    return isinstance(file_input, str) and (file_input.endswith('.txt') or os.path.exists(os.path.join("poems", str(file_input))))

def features_of_poem(file_input):
    """
    Given either a poem filename (relative to poems/) or the raw poem text,
    return a feature mapping expected by the classifier.
    The returned features format: { 'emotion_counts': {'love': 2, ...}, 'total_tokens': N }
    (classifier side expects a mapping — adapt if your classifier expects a different format)
    """
    # Read poem text
    if _is_file_input(file_input) and os.path.exists(os.path.join("poems", str(file_input))):
        filename = os.path.join("poems", str(file_input))
        with open(filename, "r", encoding='utf-8') as fh:
            file_content = fh.read()
    elif isinstance(file_input, str) and file_input.endswith('.txt') and os.path.exists(file_input):
        with open(file_input, "r", encoding='utf-8') as fh:
            file_content = fh.read()
    elif isinstance(file_input, str):
        file_content = file_input
    else:
        file_content = str(file_input)

    tokenizer = RegexpTokenizer(r"[\w']+")
    tokens = [t.lower() for t in tokenizer.tokenize(file_content)]

    stopwords_set = _load_stopwords()
    realtokens = [t for t in tokens if t not in stopwords_set and not t.isnumeric()]

    # track token -> found tags list
    trackoftoken_emotion = []

    for idx, each_token in enumerate(realtokens):
        tag_list_name, token_found = search(each_token)
        # if token found in keywords, add tags directly
        if token_found:
            trackoftoken_emotion.append({each_token: tag_list_name})
            continue

        # check tense for single-token sentences (fallback)
        tense = ""
        tense_check = determine_tense_input(each_token)
        # pick the tense with highest count greater than zero
        for k, v in tense_check.items():
            if v > 0:
                tense = k
                break

        # if past tense, try antonyms to possibly flip sentiment
        if tense == "past":
            for synset in wordn.synsets(each_token):
                for lemma in synset.lemmas():
                    if lemma.antonyms():
                        opposite_em = lemma.antonyms()[0].name()
                        tag_list_name.append(opposite_em)

        # handle negation preceding/at token
        if each_token in negation:
            # try to get next word
            if idx < len(realtokens) - 1:
                next_word = realtokens[idx + 1]
                q, token_found2 = search(next_word)
                if token_found2:
                    # attempt to use antonym of the tag word (if exists)
                    string = ''.join(q)
                    for synset in wordn.synsets(string):
                        for lemma in synset.lemmas():
                            if lemma.antonyms():
                                opposite_emotion = lemma.antonyms()[0].name()
                                tag_list_name.append(opposite_emotion)
                    # remove next_word from tokens so we don't process it twice
                    # (safe removal if still present)
                    try:
                        realtokens.remove(next_word)
                    except ValueError:
                        pass

        # If still not found, look up synonyms via WordNet and map them to tags
        if not tag_list_name:
            syns = []
            for synset in wordn.synsets(each_token):
                for lemma in synset.lemmas():
                    syns.append(lemma.name())

            found_any = False
            for s in syns:
                q, token_found3 = search(s)
                if token_found3 and q:
                    # map to first found tag
                    tagname = q[0]
                    if tagname in emotion_of_poems:
                        # optionally add this token to keywords so future runs find it
                        try:
                            path = f"keywordsfile/{tagname}.txt"
                            content = open(path, 'r', encoding='utf-8').read()
                            if each_token not in content:
                                insert(each_token, tagname)
                        except FileNotFoundError:
                            insert(each_token, tagname)
                        tag_list_name.append(tagname)
                        found_any = True
            # if no synonyms matched, leave tag_list_name empty

        trackoftoken_emotion.append({each_token: tag_list_name})

    # Build dictionary token -> list of tags (flattened)
    dictionary = {}
    for d in trackoftoken_emotion:
        for k, v in d.items():
            dictionary.setdefault(k, []).extend(v)

    # Remove tokens with no tags
    dictionary = {k: [item for item in v if item] for k, v in dictionary.items() if any(v)}

    # Count per emotion across all tokens
    count_track = {}
    for tags in dictionary.values():
        for tag in tags:
            count_track[tag] = count_track.get(tag, 0) + 1

    # If no emotion tags found, return a neutral default
    if not count_track:
        return {"emotion": "unknown", "counts": {}}

    # Pick emotion with maximum count
    max_value = max(count_track.values())
    # if tie, choose the emotion with highest count and deterministic order
    candidates = [k for k, v in count_track.items() if v == max_value]
    # deterministic selection: sorted order
    chosen = sorted(candidates)[0]
    return {"emotion": chosen, "counts": count_track}

_classifier = None
_pickle_path = os.path.join(os.path.dirname(__file__), "..", "my_classifier.pickle")
_try_paths = [
    os.path.join(os.getcwd(), "my_classifier.pickle"),
    os.path.join(os.path.dirname(os.getcwd()), "my_classifier.pickle"),
    os.path.join(os.path.dirname(__file__), "my_classifier.pickle"),
    _pickle_path,
]

for p in _try_paths:
    try:
        if p and os.path.exists(p):
            with open(p, "rb") as fh:
                _classifier = pickle.load(fh)
            break
    except Exception:
        _classifier = None

def classify(poem_text):
    global _classifier
    if _classifier is None:
        raise RuntimeError(
            "Classifier not loaded. Ensure 'my_classifier.pickle' exists at project root or in the mainfiles folder."
        )
    features = features_of_poem(poem_text)
    try:
        return _classifier.classify(features)
    except Exception as e:
        try:
            return _classifier.classify(features.get("counts", features))
        except Exception:
            raise

__all__ = ["features_of_poem", "classify"]
